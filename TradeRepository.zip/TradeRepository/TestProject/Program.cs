﻿using System;
using Transaction.API.Controllers;
using Transaction.Domain.Interfaces;
using Transaction.Data.Repositories;
using Transaction.Domain.Models;
using TradeAnalytics.API.Controllers;
using TradeAnalytics.Data.Repositories;
using TradeAnalytics.Domain.Models;
using TradeAnalytics.Domain.Interfaces;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TestProject
{
    class Program
    {
        static void PerformTransactions()
        {
            ITransactionRepository repo = new TransactionRepository();
            TransactionController controller = new TransactionController(repo);
            Transaction.Domain.Models.TransactionModel transactionModel = new Transaction.Domain.Models.TransactionModel();
            transactionModel.Amount = 100;
            transactionModel.CounterPartyName = "Ajay";
            transactionModel.BuyerId = 1;
            controller.Transact(transactionModel);
        }

        static void GetTransactionsLastHour()
        {
            ITradeReportRepository tradeReportRepository = new TradeReportRepository();
            ReportController reportController = new ReportController(tradeReportRepository);
            TransactionReportModel report = reportController.GetTransactionReportsTest("").Result;
           
            foreach (TradeAnalytics.Domain.Models.TransactionModel reportModel in report.Transactions)
            {                
                Console.WriteLine("Buyer name:- " + reportModel.BuyerName + ", " + "Amount:- " + reportModel.Amount + ", " + "CounterParty:- "+ reportModel.CounterPartyName);
            }
        }
        static void Main(string[] args)
        {
            PerformTransactions();
            //GetTransactionsLastHour();
        }
    }
}
