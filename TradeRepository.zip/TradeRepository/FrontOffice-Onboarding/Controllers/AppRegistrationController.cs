﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using FrontOffice.Authentication.Service.Domain.Models;
using Microsoft.AspNetCore.Authorization;


namespace FrontOffice.Authentication.Service.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AppRegistrationController : ControllerBase
    {


        //public AppRegistrationController(AppRegistration regService)
        //{
        //    _regService = regService;
        //}
        [AllowAnonymous]
        [HttpPost("authenticate")]
        public ClientIdSecret Authenticate([FromBody] ApplicationDetail loginParam)
        {
            var authToken = new ClientIdSecret();
            return authToken;
        }
    }
}
