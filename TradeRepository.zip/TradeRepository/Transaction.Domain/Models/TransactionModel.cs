﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Transaction.Domain.ModelToEntityConverter;
using Transaction.Domain.Entities;

namespace Transaction.Domain.Models 
{
    public class TransactionModel : IConvertModelToEntity<TransactionModel, TransactionEntity>
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int BuyerId { get; set; } 
        public string CounterPartyName { get; set; }
        public int Amount { get; set; }

        public TransactionEntity Convert() => new TransactionEntity
        {
            BuyerId = BuyerId,
            CounterPartyName = CounterPartyName,
            Amount = Amount
        };
    }
}
