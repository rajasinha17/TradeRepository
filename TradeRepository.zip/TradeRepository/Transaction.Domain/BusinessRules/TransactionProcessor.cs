﻿using System;
using System.Collections.Generic;
using System.Text;
using Transaction.Domain.Models;
using System.Threading.Tasks;
using Transaction.Domain.Entities;
using Transaction.Domain.Interfaces;


namespace Transaction.Domain.BusinessRules
{
    public class TransactionProcessor
    {
        private readonly ITransactionRepository transactionRepository;//Gets initialized using Dependency Injection.
        //public async Task<IAsyncResult> ProcessTransaction(TransactionModel transactionModel)
        //{
        //    TransactionEntity transactionEntity = transactionModel.Convert();
        //    return StatusCode(200,await transactionRepository.StoreTransactionAsync(transactionEntity));
            
        //}
    }
}
