﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transaction.Domain.ModelToEntityConverter
{
    public interface IConvertModelToEntity<Model,Entity>
    {
        Entity Convert();
    }
}
