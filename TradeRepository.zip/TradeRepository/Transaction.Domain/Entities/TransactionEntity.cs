﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Transaction.Domain.Entities
{
    public class TransactionEntity
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int TransactionID { get; set; }
        public int BuyerId { get; set; }
        public string CounterPartyName { get; set; }
        public decimal Amount { get; set; }
    }
}
