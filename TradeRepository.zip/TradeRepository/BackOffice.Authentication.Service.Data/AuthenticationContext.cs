﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BackOffice.Authentication.Service.Data
{
    class AuthenticationContext
    {
    }
}
