﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Logger.Interfaces;

namespace LogTester
{
	class Program
	{
		static void Main(string[] args)
		{
			LogManager logger = LogManager.GetLogManager();

			for (int i = 0; i < 100000000; i++)
			{
				logger.error("ERROR", "Null Pointer");
				System.Threading.Thread.Sleep(2000);
				//logger.error("ERROR", "Null Pointer");
				//logger.error("ERROR", "Null Pointer");
				//logger.error("ERROR", "Null Pointer");
				//logger.error("ERROR", "Null Pointer");
				//logger.error("ERROR", "Null Pointer");
			}
			Console.ReadLine();
		}
	}
}
