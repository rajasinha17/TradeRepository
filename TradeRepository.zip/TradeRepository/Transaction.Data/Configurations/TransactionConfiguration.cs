﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Transaction.Domain.Entities;


namespace Transaction.Data.Configurations
{
    public class TransactionConfiguration
    {
        public TransactionConfiguration(EntityTypeBuilder<TransactionEntity> transEntity)
        {
            //transEntity.HasIndex(e => e.TransactionID)
            //    .HasName("IFK_Transaction");
            transEntity.HasIndex(e => e.TransactionID);
            transEntity.Property(e => e.CounterPartyName)
                .IsRequired()
                .HasMaxLength(50);
            transEntity.Property(e => e.Amount)
                .HasColumnType("numeric");

        }
    }
}
