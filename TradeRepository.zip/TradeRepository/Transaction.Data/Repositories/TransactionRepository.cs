﻿using System;
using System.Collections.Generic;
using System.Text;
using Transaction.Domain.Interfaces;
using System.Threading.Tasks;
using Transaction.Domain.Entities;
using Newtonsoft.Json;


namespace Transaction.Data.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly TransactionContext _context = new TransactionContext();

        public TransactionRepository()
        {
            
        }

        /// <summary>
        /// Stores transaction in DB entity.
        /// </summary>
        /// <param name="transactionEntity"></param>
        /// <returns></returns>
        public async Task<bool> StoreTransactionAsync(TransactionEntity transactionEntity)
        {
            // Temporary caching just for demo/testing as real db configuration has not been done.
            
            string transactionData = JsonConvert.SerializeObject(transactionEntity);
            TestRepository.Cache.cache.Add(transactionData);
            // Temporary caching just for demo/testing as real db configuration has not been done.

            try
            {
                //Stores transaction in db entity.
                _context.Transaction.Add(transactionEntity);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            { }
            return true;
        }
    }
}
