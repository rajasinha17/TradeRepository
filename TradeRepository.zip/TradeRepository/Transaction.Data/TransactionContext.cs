﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Transaction.Domain.Entities;
using Transaction.Data.Configurations;

namespace Transaction.Data
{
    public class TransactionContext : DbContext
    {
        public virtual DbSet<TransactionEntity> Transaction { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new TransactionConfiguration(modelBuilder.Entity<TransactionEntity>());
        }
    }
}