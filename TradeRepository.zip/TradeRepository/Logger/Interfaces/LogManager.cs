﻿using System;
using System.Collections.Generic;
using System.Text;
using Logger.Model;
using Logger.Core;
using Logger.Cache;
using Logger.Subscriber;

namespace Logger.Interfaces
{
	public sealed class LogManager
	{
		private static LogManager logManager = null;
		private static readonly object lockObj = new object();
		private static LogQueue queue = new LogQueue();
		private LogDispatcher logDispatcher = new LogDispatcher();
		private ISubscriber consoleLogSubs = new ConsoleLoggerSubscriber();
		private LogManager()
		{
			queue.SetHandler(logDispatcher.ReadLogsFromQueue);

			//Subscribtion happens based on log policy.
			logDispatcher.Subscribe(consoleLogSubs);
		}

		public static LogManager GetLogManager()
		{
			lock (lockObj)
			{
				if (logManager == null)
				{
					logManager = new LogManager();
					
				}
				return logManager;
			}
		}

		public void message(string tag, string message)
		{
			ILog log = new Log();			
			log.tag = tag;
			log.message = message;
			log.timeStamp = DateTime.Now;
			queue.Enqueue(log);

		}

		public void error(string tag, string message)
		{
			ILog log = new Log();			
			log.tag = tag;
			log.message = message;
			log.timeStamp = DateTime.Now;
			queue.Enqueue(log);
		}

		public void debug(string tag, string message)
		{
			ILog log = new Log();			
			log.tag = tag;
			log.message = message;
			log.timeStamp = DateTime.Now;
			queue.Enqueue(log);
		}

		
	}
}
