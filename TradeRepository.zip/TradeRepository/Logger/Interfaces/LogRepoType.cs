﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Interfaces
{
	public sealed class LogRepoType
	{
		public static UInt16 FILE = 1;
		public static UInt16 DB = 2;
	}
}
