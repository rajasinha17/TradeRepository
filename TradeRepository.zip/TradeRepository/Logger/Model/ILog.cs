﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Model
{
	public interface ILog
	{
		DateTime timeStamp { set; get; }
		string message { set; get; }
		string tag { set; get; }
	}
}
