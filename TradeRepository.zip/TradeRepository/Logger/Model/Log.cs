﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Model
{
	class Log : ILog
	{
		public DateTime timeStamp { set; get; }
		public string message { set; get; }
		public string tag { set; get; }	
	
	}
}
