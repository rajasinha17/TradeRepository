﻿using System;
using System.Collections.Generic;
using System.Text;
using Logger.Model;
using System.Threading;
using System.Threading.Tasks;

namespace Logger.Subscriber
{
	class ConsoleLoggerSubscriber : ISubscriber
	{
		SemaphoreSlim semaphoreSlim = new SemaphoreSlim(1, 1);
		public void NotifyLogAvailability(List<ILog> logs)
		{
			WriteLogsAsync(logs);
		}

		/// <summary>
		/// Write logs asynchronously.
		/// Log File path is read from the log configuration.
		/// </summary>
		/// <param name="logs"></param>
		private async void WriteLogsAsync(List<ILog> logs)
		{
			Console.WriteLine("		LogDispatch:: Entering a long write operation");
			await semaphoreSlim.WaitAsync();
			try
			{
				//Simulating log write operation.
				await Task.Delay(10000);
				foreach (ILog log in logs)
				{
					Console.WriteLine("<< " + log.timeStamp.ToString() + " , " + log.message + " >>");
				}
			}
			finally
			{
				semaphoreSlim.Release();
			}
			Console.WriteLine("		LogDispatch:: Completed write operation");
		}
	}
}
