﻿using System;
using System.Collections.Generic;
using System.Text;
using Logger.Model;
using System.Threading;
namespace Logger.Subscriber
{
	class FileLoggerSubscriber : ISubscriber
	{
		SemaphoreSlim semaphoreSlim = new SemaphoreSlim(1, 1);
		public void NotifyLogAvailability(List<ILog> logs)
		{
			WriteLogsAsync(logs);			
		}

		/// <summary>
		/// Write logs asynchronously.
		/// Log File path is read from the log configuration.
		/// </summary>
		/// <param name="logs"></param>
		private async void WriteLogsAsync(List<ILog> logs)
		{
			await semaphoreSlim.WaitAsync();
			//File writing code TBD.
			semaphoreSlim.Release();
		}

	}
}
