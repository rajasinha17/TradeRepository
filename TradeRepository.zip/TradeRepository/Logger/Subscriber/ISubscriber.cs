﻿using System;
using System.Collections.Generic;
using System.Text;
using Logger.Core;
using Logger.Model;

namespace Logger.Subscriber
{
	public interface ISubscriber
	{
		void NotifyLogAvailability(List<ILog> logs);
	}
}
