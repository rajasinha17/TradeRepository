﻿using System;
using System.Collections.Generic;
using System.Text;
using Logger.Model;

namespace Logger.Subscriber
{
	class DBLoggerSubscriber : ISubscriber
	{
		public void NotifyLogAvailability(List<ILog> logs)
		{
			//DB write TBD.
		}
	}
}
