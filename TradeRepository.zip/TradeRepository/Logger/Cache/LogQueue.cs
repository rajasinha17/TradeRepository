﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Concurrent;
using Logger.Model;

namespace Logger.Cache
{
	sealed class LogQueue
	{
		private ConcurrentQueue<ILog> queue = new ConcurrentQueue<ILog>();
		private EventHandler eventHandler = null;

		public void SetHandler(EventHandler handler)
		{
			eventHandler = handler;
		}

		public void Enqueue(ILog log)
		{
			Console.WriteLine("Logging in the queue:- " + log.message);
			queue.Enqueue(log);

			//
			// Dispatch event is triggered based on certain policies such as,
			// a) when an error occurs 
			// b) When queue size reaches a hypothetical number 
			// c) custom events
			//
			if (queue.Count > 5)
			{
				//Console.WriteLine("Queue is full");
				eventHandler(this,null);					
			}
		}

		public List<ILog> GetAllLogs()
		{
			List<ILog> listOfLogs = new List<ILog>();			
			while (!queue.IsEmpty)
			{
				ILog log = null;
				queue.TryDequeue(out log);
				if (log != null)
				{
					listOfLogs.Add(log);
				}
			}
			return listOfLogs;
		}

		public IEnumerator<ILog> GetEnumerator()
		{
			return queue.GetEnumerator();				
		}
	}
}
