﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Logger.Model;
using Logger.Subscriber;
using Logger.Cache;

namespace Logger.Core
{
	public class LogDispatcher
	{
		static readonly object _object = new object();
		static SemaphoreSlim semaphoreSlim = new SemaphoreSlim(1, 1);
		IList<ISubscriber> subscribers = new List<ISubscriber>(); // All the log observers such as UI, File, Console objects are stored.
		public async void ReadLogsFromQueue(object sender, EventArgs args)
		{
			await semaphoreSlim.WaitAsync();
			List<ILog> logs = (sender as LogQueue).GetAllLogs();
			await Task.Run(() => SendLogsToSubscribers(logs));			
		}

		/// <summary>
		/// Adds a log subscriber in the subscriber list.
		/// </summary>
		/// <param name="subscriber"></param>
		public void Subscribe(ISubscriber subscriber)
		{
			subscribers.Add(subscriber);							
		}

		/// <summary>
		/// Notifies the subscribers that new logs are available 
		/// </summary>
		private void SendLogsToSubscribers(List<ILog> logs)
		{
			foreach (ISubscriber subscriber in subscribers)
			{
				subscriber.NotifyLogAvailability(logs);
			}
		}

		
		//private void FormDispatchableContent(object sender, ref StringBuilder contentForDB, ref StringBuilder contentForFile)
		//{
		//	LogQueue logQueue = sender as LogQueue;
		//	IEnumerator<ILog> enumerator = logQueue.GetEnumerator();

		//	while (enumerator.MoveNext())
		//	{
		//		ILog log = enumerator.Current;
		//		if (log is DBLog)
		//		{
		//			//Form content for db.					
		//		}
		//		if (log is FileLog)
		//		{
		//			//Form content for file.					
		//		}
		//	}
		//}

		
	}
}
