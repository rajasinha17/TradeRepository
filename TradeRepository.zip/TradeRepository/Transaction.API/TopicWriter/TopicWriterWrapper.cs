﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Transaction.API.TopicWriter
{
    public class TopicWriterWrapper
    {
        /// <summary>
        /// Writes a transaction to Topic published in Kafka.
        /// </summary>
        /// <returns></returns>
        public async Task writeTransactionToTopic(string transaction)
        {
            await Task.FromResult(true);
        }
    }
}
