﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Transaction.Domain.BusinessRules;
using Transaction.Domain.Models;
using Transaction.Domain.Interfaces;
using Transaction.Domain.Entities;
using Transaction.API.TopicWriter;
using Newtonsoft.Json;

namespace Transaction.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TransactionController : ControllerBase
    {           
        private readonly ITransactionRepository _transactionRepository = null;//Gets initialized using Dependency Injection.
        private readonly TopicWriterWrapper topicWriter = new TopicWriterWrapper(); 

        public TransactionController(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository;
        }

        
        [HttpPost("transact")]
        public async Task<IActionResult> Transact([FromBody] TransactionModel transactionModel)
        {
            try
            {
                if (transactionModel == null)
                    return BadRequest();

                //
                // Write the transaction to Topic(currently Kafka), asynchronously.
                // This is to achieve real time streaming of transaction record to subscribed applications.
                //
                string strTransaction = JsonConvert.SerializeObject(transactionModel);
                await topicWriter.writeTransactionToTopic(strTransaction);

                //Writes data to database(currenly Cassandra).
                TransactionEntity transactionEntity = transactionModel.Convert();
                return StatusCode(200,await _transactionRepository.StoreTransactionAsync(transactionEntity));
            }
            catch (Exception ex)
            {
                return StatusCode(500,ex);
            }
        }

    }
}
