﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using BackOffice.Authentication.Service.Domain.Models;

namespace BackOffice.Authentication.Service.API.Controllers
{
    [ApiController]
    [Route("[api/onboarding]")]
    public class AuthenticationController : ControllerBase
    {

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public ClientIdSecret Authenticate([FromBody] ApplicationDetail loginParam)
        {
            var authToken = new ClientIdSecret();
            return authToken;
        }
    }
}
