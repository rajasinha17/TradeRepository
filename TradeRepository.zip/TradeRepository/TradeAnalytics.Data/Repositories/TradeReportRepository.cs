﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeAnalytics.Domain.Interfaces;
using TradeAnalytics.Domain.Models;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TradeAnalytics.Data.Repositories
{
    public class TradeReportRepository : ITradeReportRepository
    {
        private readonly TradeAnalyticsContext _context = new TradeAnalyticsContext();
        public async Task<TransactionReportModel> GetTradeReportAsync(ReportFilterTimeRangeModel filter)
        {
            //Returning dummy Report.
            //TransactionReportModel transRepModel = new TransactionReportModel();
            //transRepModel.Transactions = new List<TransactionModel>();
            //transRepModel.Transactions.Add(new TransactionModel()
            //{
            //    Amount = 100,
            //    BuyerName = "Brandon",
            //    CounterPartyName = "Jonathan",
            //    TimeStamp = new DateTime(2019, 11, 25)                
            //});

            // Returning data from the test cache as db has not been configured.
            TransactionReportModel transRepModel = new TransactionReportModel();
            transRepModel.Transactions = new List<TransactionModel>();
            foreach (string transaction in TestRepository.Cache.cache)
            {
                transRepModel.Transactions.Add((TransactionModel)JsonConvert.DeserializeObject(transaction));
            }

            return await Task.FromResult<TransactionReportModel>(transRepModel);
            //_context.TransactionReport.FindAsync(filter);
        }



    }
}
