﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using TradeAnalytics.Domain.Entities;

namespace TradeAnalytics.Data
{
    public class TradeAnalyticsContext : DbContext
    {
        public virtual DbSet<TransactionReportEntity> TransactionReport { get; set; }

    }
}
