﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FrontOffice.Authentication.Service.Data
{
    class AuthenticationContext
    {
    }
}
