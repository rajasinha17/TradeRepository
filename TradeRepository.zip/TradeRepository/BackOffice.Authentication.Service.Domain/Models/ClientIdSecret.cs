﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackOffice.Authentication.Service.Domain.Models
{
    public class ClientIdSecret
    {
        public string ClientID { get; set; }
        public string Secret { get; set; }
    }
}
