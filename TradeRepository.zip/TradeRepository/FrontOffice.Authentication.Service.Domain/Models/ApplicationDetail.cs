﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontOffice.Authentication.Service.Domain.Models
{
    public class ApplicationDetail
    {
        public string AppName { get; set; }
        public string RedirectURL { get; set; }
        public string AppDescription { get; set; }
    }
}
