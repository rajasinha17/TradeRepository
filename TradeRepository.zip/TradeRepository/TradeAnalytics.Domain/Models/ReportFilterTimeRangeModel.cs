﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeAnalytics.Domain.Models
{
    public class ReportFilterTimeRangeModel
    {
        DateTime StartTime { get; set; }
        DateTime EndTime { get; set; }
    }
}
