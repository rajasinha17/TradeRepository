﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TradeAnalytics.Domain.Entities;
using TradeAnalytics.Domain.ModelToEntityConverter;

namespace TradeAnalytics.Domain.Models 
{
    public class TransactionModel : IConvertModelToEntity<TransactionModel, TransactionEntity>
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int TransactionId { get; set; }
        public string BuyerName { get; set; } 
        public string CounterPartyName { get; set; }
        public int Amount { get; set; }
        public DateTime TimeStamp { get; set; }

        public TransactionEntity Convert() => new TransactionEntity
        {            
            BuyerName = BuyerName,
            CounterPartyName = CounterPartyName,
            Amount = Amount
        };
    }
}
