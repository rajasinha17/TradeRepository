﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeAnalytics.Domain.Models
{
    public class TransactionReportModelComp
    {
        public List<TransactionModel> TransactionsLastHour { get; set; }

        public List<TransactionModel> TransactionsLastWeek { get; set; }

        public List<TransactionModel> TransactionsLastMonth { get; set; }

    }
}
