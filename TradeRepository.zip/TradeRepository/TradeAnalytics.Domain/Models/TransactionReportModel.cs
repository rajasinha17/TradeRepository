﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeAnalytics.Domain.ModelToEntityConverter;
using TradeAnalytics.Domain.Entities;

namespace TradeAnalytics.Domain.Models
{
    /// <summary>
    /// List of transactions requested for a particual date range.
    /// 
    /// </summary>
    public class TransactionReportModel : IConvertModelToEntity<TransactionReportModel, TransactionReportEntity>
    {
        public List<TransactionModel> Transactions { get; set; }

        public TransactionReportEntity Convert() => new TransactionReportEntity
        {
            //Some auto converter will be used.
        };
    }
}
