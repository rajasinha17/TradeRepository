﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeAnalytics.Domain.Entities
{
    public class TransactionReportEntity
    {
        public List<TransactionEntity> Transactions { get; set; }
    }
}
