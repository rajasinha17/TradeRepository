﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeAnalytics.Domain.Entities;
using TradeAnalytics.Domain.Models;

namespace TradeAnalytics.Domain.ReportBuilderPattern
{
    /// <summary>
    /// Any combination of inputs for reports such as hourly+monthy or weekly + monthly or hourly + weekly + monthly or any custom
    /// report can be built and returned as a single object using ReportBuilder.
    /// 
    /// Report builing examples:-
    /// 
    /// Report weekMonth = new ReportBuilder().LastWeek(reportEntityLastWeek).LastMonth(reportEntityLastMonth).build();
    /// Report all = new ReportBuilder().LastHour(reportEntityLastHour).LastWeek(reportEntityLastWeek).LastMonth(reportEntityLastMonth).build();
    /// </summary>
    /// 
    public class ReportBuilder
    {
        TransactionReportModelComp report = new TransactionReportModelComp();
        public ReportBuilder()
        { 
            
        }

        public ReportBuilder LastHour(TransactionReportEntity reportEntity)
        {
            //convert reportEntity to transaction model.
            //report.TransactionsLastHour = reportEntity.Convert();
            return this;
        }

        public ReportBuilder LastWeek(TransactionReportEntity reportEntity)
        {
            //convert reportEntity to transaction model.
            //report.TransactionsLastWeek = reportEntity.Convert();
            return this;
        }

        public ReportBuilder LastMonth(TransactionReportEntity reportEntity)
        {
            //convert reportEntity to transaction model.
            //report.TransactionsLastMonth = reportEntity.Convert();
            return this;
        }

        public TransactionReportModelComp build()
        {
            return report;
        }
    }
}


