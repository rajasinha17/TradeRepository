﻿using System;
using System.Collections.Generic;
using System.Text;
using TradeAnalytics.Domain.Models;
using System.Threading.Tasks;

namespace TradeAnalytics.Domain.Interfaces
{
    public interface ITradeReportRepository
    {
        Task<TransactionReportModel> GetTradeReportAsync(ReportFilterTimeRangeModel filter);
    }
}
