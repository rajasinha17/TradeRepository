﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeAnalytics.Domain.ModelToEntityConverter
{
    public interface IConvertModelToEntity<Model,Entity>
    {
        Entity Convert();
    }
}
