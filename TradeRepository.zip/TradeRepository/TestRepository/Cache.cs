﻿using System;
using System.Collections.Generic;

namespace TestRepository
{
    public class Cache
    {
        public static List<string> cache = new List<string>();
    }
}
