﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TradeAnalytics.Domain.Models;
using TradeAnalytics.Domain.Interfaces;

namespace TradeAnalytics.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ReportController : ControllerBase
    {
        private readonly ITradeReportRepository _tradeRepo;

        //public ReportController()
        //{ 
        
        //}


        /// <summary>
        /// Trade repository object can be injected through dependency injection.
        /// </summary>
        /// <param name="tradeRepo"> object can be injected through dependency injection.</param>
        public ReportController(ITradeReportRepository tradeRepo)
        {
            _tradeRepo = tradeRepo;
        }

        /// <summary>
        /// Accepts a json string as a parameter ,rather than a specific date range.
        /// There can be multiple date ranges, or the query parameter can be complex.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ct"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("transactionreports")]
        [Produces(typeof(TransactionReportModel))]
        public async Task<ActionResult<TransactionReportModel>> GetTransactionReports(string queryParam)
        {
            try
            {
                ////Dummy report
                //TransactionReportModel rep = new TransactionReportModel();
                //rep.Transactions = new List<TransactionModel>();
                //rep.Transactions.Add(new TransactionModel() { BuyerName = "Raja", Amount = 100, CounterPartyName = "Ajay" });

                //return rep;
                ////
                ReportFilterTimeRangeModel filterModel = Convert(queryParam);
                var transactionReport = await _tradeRepo.GetTradeReportAsync(filterModel);
                if (transactionReport == null)
                {
                    return NotFound();
                }

                return Ok(transactionReport);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }
        }

        [HttpGet]
        [Route("transactionreportstest")]
        [Produces(typeof(TransactionReportModel))]
        public async Task<TransactionReportModel> GetTransactionReportsTest(string queryParam)
        {
            try
            {
                ////Dummy report
                //TransactionReportModel rep = new TransactionReportModel();
                //rep.Transactions = new List<TransactionModel>();
                //rep.Transactions.Add(new TransactionModel() { BuyerName = "Raja", Amount = 100, CounterPartyName = "Ajay" });

                //return rep;
                ////
                ReportFilterTimeRangeModel filterModel = Convert(queryParam);
                var transactionReport = await _tradeRepo.GetTradeReportAsync(filterModel);
                

                return transactionReport;
            }
            catch (Exception ex)
            {
                //return StatusCode(500, ex);
                return null;
            }
        }

        /// <summary>
        /// Converts the json query paramaeter to Entity Friendly Filter.
        /// </summary>
        /// <returns></returns>
        private ReportFilterTimeRangeModel Convert(string queryParam)
        {
            return new ReportFilterTimeRangeModel();
        }

        //[HttpGet]
        //[Route("getName")]
        //public string GetName(string param)
        //{
        //    return param + " Processed";
        //}

    }
}
